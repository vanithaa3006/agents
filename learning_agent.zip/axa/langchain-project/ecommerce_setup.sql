-- E-commerce demo database schema and seed data for the LangChain capstone
-- This script is intended for SQLite.

-- Drop existing tables if they exist
DROP TABLE IF EXISTS email_logs;
DROP TABLE IF EXISTS messages;
DROP TABLE IF EXISTS conversations;
DROP TABLE IF EXISTS pending_actions;
DROP TABLE IF EXISTS tickets;
DROP TABLE IF EXISTS returns;
DROP TABLE IF EXISTS payments;
DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS users;

-- Users (customers + admin)
CREATE TABLE users (
  id INTEGER PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  password TEXT NOT NULL, -- plain text for this project only
  full_name TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('customer', 'admin')),
  created_at TEXT NOT NULL
);

-- Products
CREATE TABLE products (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  price REAL NOT NULL,
  stock_qty INTEGER NOT NULL
);

-- Orders
CREATE TABLE orders (
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL,
  status TEXT NOT NULL,
  order_date TEXT NOT NULL,
  total_amount REAL NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Order items
CREATE TABLE order_items (
  id INTEGER PRIMARY KEY,
  order_id INTEGER NOT NULL,
  product_id INTEGER NOT NULL,
  quantity INTEGER NOT NULL,
  unit_price REAL NOT NULL,
  FOREIGN KEY (order_id) REFERENCES orders(id),
  FOREIGN KEY (product_id) REFERENCES products(id)
);

-- Payments
CREATE TABLE payments (
  id INTEGER PRIMARY KEY,
  order_id INTEGER NOT NULL,
  amount REAL NOT NULL,
  status TEXT NOT NULL,
  payment_method TEXT NOT NULL,
  transaction_reference TEXT,
  paid_at TEXT,
  FOREIGN KEY (order_id) REFERENCES orders(id)
);

-- Returns
CREATE TABLE returns (
  id INTEGER PRIMARY KEY,
  order_id INTEGER NOT NULL,
  order_item_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  reason TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('PENDING', 'APPROVED', 'REJECTED')),
  requested_at TEXT NOT NULL,
  resolved_at TEXT,
  admin_id INTEGER,
  FOREIGN KEY (order_id) REFERENCES orders(id),
  FOREIGN KEY (order_item_id) REFERENCES order_items(id),
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (admin_id) REFERENCES users(id)
);

-- Tickets (human-in-the-loop, links to returns)
CREATE TABLE tickets (
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL,
  return_id INTEGER,
  subject TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('OPEN', 'IN_REVIEW', 'RESOLVED', 'CLOSED')),
  thread_id TEXT,      -- conversation UUID from the LangChain checkpointer
  user_email TEXT,     -- cached login email for convenience when resuming conversations
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (return_id) REFERENCES returns(id)
);

-- Pending Actions (HITL - stores interrupted actions waiting for admin approval)
CREATE TABLE pending_actions (
  id INTEGER PRIMARY KEY,
  thread_id TEXT NOT NULL,           -- conversation thread ID (user_email:conversation_id)
  user_email TEXT NOT NULL,          -- customer email
  action_type TEXT NOT NULL CHECK (action_type IN ('CANCEL_ORDER', 'CREATE_RETURN')),
  order_id INTEGER NOT NULL,          -- order ID for the action
  product_name TEXT,                 -- product name (for returns, NULL for cancellations)
  reason TEXT,                        -- reason (for returns, NULL for cancellations)
  status TEXT NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING', 'APPROVED', 'REJECTED')),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY (order_id) REFERENCES orders(id)
);

-- Optional: conversations and messages tables (sample data only; not required for checkpointer design)
CREATE TABLE conversations (
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL,
  role TEXT NOT NULL,
  started_at TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('ACTIVE', 'CLOSED')),
  FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE messages (
  id INTEGER PRIMARY KEY,
  conversation_id INTEGER NOT NULL,
  sender_type TEXT NOT NULL CHECK (sender_type IN ('user', 'bot', 'admin')),
  content TEXT NOT NULL,
  created_at TEXT NOT NULL,
  FOREIGN KEY (conversation_id) REFERENCES conversations(id)
);

-- Email logs
CREATE TABLE email_logs (
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL,
  email TEXT NOT NULL,
  subject TEXT NOT NULL,
  body_preview TEXT,
  email_type TEXT NOT NULL,
  sent_at TEXT NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Seed data

-- Users (3 customers + 1 admin)
INSERT INTO users (id, email, password, full_name, role, created_at) VALUES
  (1, 'sivaprasad.valluru@gmail.com',   'siva@123',   'Siva ',   'customer', '2024-09-15T10:00:00'),
  (2, 'bob@example.com',     'bob123',     'Bob Customer',     'customer', '2024-09-30T10:00:00'),
  (3, 'charlie@example.com', 'charlie123', 'Charlie Customer', 'customer', '2024-10-15T10:00:00'),
  (4, 'admin@example.com',   'admin123',   'Admin User',       'admin',    '2024-08-20T10:00:00');

-- Products
INSERT INTO products (id, name, description, price, stock_qty) VALUES
  (1, 'Wireless Mouse',              'Ergonomic wireless mouse',             25.99, 100),
  (2, 'Mechanical Keyboard',         'Backlit mechanical keyboard',          79.99, 50),
  (3, 'Noise Cancelling Headphones', 'Over-ear headphones',                 129.99, 30),
  (4, 'USB-C Charger',               '65W fast charger',                     19.99, 200),
  (5, 'Laptop Stand',                'Adjustable aluminum laptop stand',     39.99, 80);

-- Orders
INSERT INTO orders (id, user_id, status, order_date, total_amount) VALUES
  (1, 1, 'DELIVERED', '2024-10-01T09:00:00', 105.98),
  (2, 1, 'SHIPPED',   '2024-10-16T09:00:00', 129.99),
  (3, 2, 'PLACED',    '2024-10-19T09:00:00', 39.98),
  (4, 3, 'CANCELLED', '2024-10-11T09:00:00', 39.99);

-- Order items
INSERT INTO order_items (id, order_id, product_id, quantity, unit_price) VALUES
  (1, 1, 1, 1, 25.99),
  (2, 1, 2, 1, 79.99),
  (3, 2, 3, 1, 129.99),
  (4, 3, 4, 2, 19.99),
  (5, 4, 5, 1, 39.99);

-- Payments
INSERT INTO payments (id, order_id, amount, status, payment_method, transaction_reference, paid_at) VALUES
  (1, 1, 105.98, 'PAID',     'CARD', 'TXN-ALICE-001',   '2024-10-01T10:00:00'),
  (2, 2, 129.99, 'PAID',     'CARD', 'TXN-ALICE-002',   '2024-10-16T10:00:00'),
  (3, 3, 39.98,  'PAID',     'UPI',  'TXN-BOB-001',     '2024-10-19T10:00:00'),
  (4, 4, 39.99,  'REFUNDED', 'CARD', 'TXN-CHARLIE-001', '2024-10-12T10:00:00');

-- Returns
INSERT INTO returns (id, order_id, order_item_id, user_id, reason, status, requested_at, resolved_at, admin_id) VALUES
  (1, 1, 2, 1, 'Keys are sticking, want to return.', 'PENDING',
   '2024-10-18T09:00:00', NULL, NULL),
  (2, 3, 4, 2, 'Received wrong color.', 'APPROVED',
   '2024-10-12T09:00:00', '2024-10-14T09:00:00', 4);

-- Tickets (linked to returns, with example conversation UUIDs)
INSERT INTO tickets (id, user_id, return_id, subject, status, thread_id, user_email, created_at, updated_at) VALUES
  (1, 1, 1, 'Return request for mechanical keyboard', 'OPEN',
   'conv-alice-1', 'alice@example.com',
   '2024-10-18T09:05:00', '2024-10-18T09:05:00'),
  (2, 2, 2, 'Return request for USB-C charger', 'RESOLVED',
   'conv-bob-1', 'bob@example.com',
   '2024-10-12T09:10:00', '2024-10-14T09:10:00');

-- Sample conversation + messages (optional example)
INSERT INTO conversations (id, user_id, role, started_at, status) VALUES
  (1, 1, 'customer', '2024-10-20T09:00:00', 'ACTIVE');

INSERT INTO messages (id, conversation_id, sender_type, content, created_at) VALUES
  (1, 1, 'user', 'Hi, I want to know the status of my last order.', '2024-10-20T09:01:00'),
  (2, 1, 'bot',  'Your last order is currently SHIPPED and should arrive tomorrow.', '2024-10-20T09:01:30');

-- Email logs
INSERT INTO email_logs (id, user_id, email, subject, body_preview, email_type, sent_at) VALUES
  (1, 2, 'bob@example.com',
   'Your return has been approved',
   'Your return request for USB-C charger has been approved.',
   'RETURN_UPDATE',
   '2024-10-14T09:15:00');


